"use client";

import { useEffect, useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Ciao! Sono l’assistente AI di AI Ads Revolution. Dimmi cosa vuoi migliorare: campagne, KPI, creatività o setup.",
    },
  ]);

  const bodyRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (open && bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [open, msgs]);

  async function send() {
    const text = input.trim();
    if (!text) return;
    setInput("");

    const next = [...msgs, { role: "user", content: text }];
    setMsgs(next);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });

      if (!res.ok) {
        const t = await res.text();
        setMsgs((m) => [
          ...m,
          { role: "assistant", content: "Errore chat server: " + t },
        ]);
        return;
      }

      const data = await res.json();
      setMsgs((m) => [...m, { role: "assistant", content: data.reply || "Ok." }]);
    } catch (e: any) {
      setMsgs((m) => [
        ...m,
        { role: "assistant", content: "Errore rete: " + String(e?.message || e) },
      ]);
    }
  }

  return (
    <>
      <button className="aar-chat-fab" onClick={() => setOpen((v) => !v)} aria-label="Apri chat AI">
        <span style={{ fontWeight: 800, fontSize: 14 }}>AI</span>
      </button>

      {open && (
        <div className="aar-chat-panel" role="dialog" aria-label="AI Chat">
          <div className="aar-chat-header">
            <div className="aar-chat-title">
              <div className="aar-logo" style={{ width: 28, height: 28, borderRadius: 10 }}>
                <img src="/aiads-logo.svg" alt="AI Ads Revolution" />
              </div>
              <div>
                <b>AI Assistant</b>
                <div style={{ fontSize: 12, color: "var(--aar-muted)" }}>H24 • setup & campagne</div>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              style={{
                height: 30,
                padding: "0 10px",
                borderRadius: 10,
                border: "1px solid rgba(255,255,255,.14)",
                background: "rgba(255,255,255,.06)",
                color: "var(--aar-text)",
                cursor: "pointer",
              }}
            >
              Chiudi
            </button>
          </div>

          <div className="aar-chat-body" ref={bodyRef}>
            {msgs.map((m, i) => (
              <div key={i} className={`aar-msg ${m.role}`}>
                <div className="aar-bubble">{m.content}</div>
              </div>
            ))}
          </div>

          <div className="aar-chat-input">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Scrivi qui… (es. ‘Perché CTR è 0?’)"
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
              }}
            />
            <button className="primary" onClick={send}>
              Invia
            </button>
          </div>
        </div>
      )}
    </>
  );
}
