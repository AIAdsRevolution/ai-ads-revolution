import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const messages = Array.isArray(body?.messages) ? body.messages : [];
  const last = messages.length ? messages[messages.length - 1]?.content : "";

  // Placeholder "assistant" reply (now). Later we connect to your real AI-Core / OpenAI / etc.
  const reply =
    "Ricevuto ✅\n" +
    "Messaggio: " +
    String(last || "") +
    "\n\n" +
    "Modalità DEMO: appena mi dai OK, collego questa chat al tuo AI-Core (o a un provider AI) e diventa H24 reale.";

  return NextResponse.json({ reply });
}
