"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; text: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", text: "Ciao! Sono l’assistente AI di AI Ads Revolution. Dimmi cosa vuoi ottimizzare 👇" },
  ]);

  const boxRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // ESC per chiudere
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, open]);

  const canSend = text.trim().length > 0;

  async function send() {
    const q = text.trim();
    if (!q) return;

    setText("");
    setMsgs((m) => [...m, { role: "user", text: q }]);

    // DEMO: risposta placeholder (poi la colleghiamo a /api/ai-assistant o al tuo AI-Core)
    const demo = pickDemo(q);
    setTimeout(() => {
      setMsgs((m) => [...m, { role: "assistant", text: demo }]);
    }, 350);
  }

  function pickDemo(q: string) {
    const s = q.toLowerCase();
    if (s.includes("roas")) return "Suggerimento: controlla campagne con ROAS < 1.2 e sposta budget su quelle con CTR più alto. Vuoi che analizzi una campagna specifica?";
    if (s.includes("ctr")) return "Per alzare il CTR: test A/B di headline, keyword più intent-based, e creatività più diretta. Dimmi settore e obiettivo (lead/vendite).";
    if (s.includes("budget")) return "Posso proporti una riallocazione: 70% su campagne migliori, 20% test, 10% brand. Che budget giornaliero hai?";
    return "Perfetto. Dimmi: obiettivo (lead/vendite), budget e canale (Search/Display/PMax). Ti preparo un piano di ottimizzazione.";
  }

  // Stili inline “safe” (non dipendono da Tailwind)
  const styles = useMemo(() => {
    const glass = "rgba(15, 20, 30, 0.72)";
    const stroke = "rgba(255,255,255,0.10)";
    return {
      wrap: {
        position: "fixed" as const,
        right: 18,
        bottom: 18,
        zIndex: 2147483647, // sopra tutto
        pointerEvents: "auto" as const,
        fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial",
      },
      fab: {
        width: 58,
        height: 58,
        borderRadius: 999,
        border: `1px solid ${stroke}`,
        background: "linear-gradient(135deg, #0A84FF 0%, #4F46E5 55%, #7C3AED 100%)",
        boxShadow: "0 18px 45px rgba(0,0,0,.45)",
        display: "grid",
        placeItems: "center",
        color: "white",
        cursor: "pointer",
        userSelect: "none" as const,
      },
      panel: {
        width: 360,
        height: 520,
        borderRadius: 18,
        border: `1px solid ${stroke}`,
        background: `linear-gradient(180deg, ${glass} 0%, rgba(10,12,18,.88) 100%)`,
        boxShadow: "0 22px 70px rgba(0,0,0,.55)",
        overflow: "hidden",
        backdropFilter: "blur(14px)",
        marginBottom: 10,
      },
      header: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "12px 12px",
        borderBottom: `1px solid ${stroke}`,
      },
      brand: { display: "flex", gap: 10, alignItems: "center" },
      dot: {
        width: 10,
        height: 10,
        borderRadius: 999,
        background: "radial-gradient(circle at 30% 30%, #B9D7FF 0%, #0A84FF 40%, #1D4ED8 100%)",
        boxShadow: "0 0 0 6px rgba(10,132,255,.12)",
      },
      title: { fontWeight: 700, fontSize: 13, lineHeight: "16px", color: "rgba(255,255,255,.92)" },
      sub: { fontSize: 12, color: "rgba(255,255,255,.55)" },
      close: {
        width: 36,
        height: 36,
        borderRadius: 12,
        border: `1px solid ${stroke}`,
        background: "rgba(255,255,255,.06)",
        color: "rgba(255,255,255,.85)",
        cursor: "pointer",
      },
      body: {
        padding: 12,
        height: 380,
        overflow: "auto" as const,
      },
      bubbleUser: {
        marginLeft: "auto",
        maxWidth: "82%",
        padding: "10px 12px",
        borderRadius: 14,
        background: "rgba(10,132,255,.18)",
        border: `1px solid rgba(10,132,255,.25)`,
        color: "rgba(255,255,255,.92)",
        marginBottom: 10,
      },
      bubbleBot: {
        marginRight: "auto",
        maxWidth: "82%",
        padding: "10px 12px",
        borderRadius: 14,
        background: "rgba(255,255,255,.06)",
        border: `1px solid ${stroke}`,
        color: "rgba(255,255,255,.90)",
        marginBottom: 10,
      },
      inputRow: {
        display: "flex",
        gap: 8,
        padding: 12,
        borderTop: `1px solid ${stroke}`,
        background: "rgba(0,0,0,.18)",
      },
      input: {
        flex: 1,
        borderRadius: 12,
        border: `1px solid ${stroke}`,
        background: "rgba(255,255,255,.06)",
        padding: "10px 12px",
        color: "rgba(255,255,255,.92)",
        outline: "none",
      },
      send: {
        width: 44,
        borderRadius: 12,
        border: `1px solid ${stroke}`,
        background: "linear-gradient(135deg, #0A84FF 0%, #4F46E5 60%, #7C3AED 100%)",
        color: "white",
        cursor: "pointer",
      },
    };
  }, []);

  return (
    <div style={styles.wrap}>
      {open && (
        <div ref={boxRef} style={styles.panel} aria-label="AI Ads Revolution Assistant">
          <div style={styles.header}>
            <div style={styles.brand}>
              <div style={styles.dot} />
              <div>
                <div style={styles.title}>AI Ads Assistant</div>
                <div style={styles.sub}>H24 • demo (colleghiamo AI-Core)</div>
              </div>
            </div>
            <button style={styles.close} onClick={() => setOpen(false)} aria-label="Chiudi chat">
              ✕
            </button>
          </div>

          <div style={styles.body}>
            {msgs.map((m, i) => (
              <div key={i} style={m.role === "user" ? styles.bubbleUser : styles.bubbleBot}>
                {m.text}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          <div style={styles.inputRow}>
            <input
              style={styles.input}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Scrivi qui… (es: migliora ROAS)"
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
              }}
            />
            <button style={styles.send} onClick={send} disabled={!canSend} aria-label="Invia">
              ➤
            </button>
          </div>
        </div>
      )}

      <div
        style={styles.fab}
        role="button"
        aria-label="Apri chat AI"
        onClick={() => setOpen((v) => !v)}
        title="AI Assistant"
      >
        AI
      </div>
    </div>
  );
}
