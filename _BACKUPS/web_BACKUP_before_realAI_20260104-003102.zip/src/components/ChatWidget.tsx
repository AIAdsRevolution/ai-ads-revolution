"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";

type Msg = { role: "assistant" | "user"; content: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Ciao 👋 sono **AI Ads Assistant** (AI Ads Revolution), disponibile 24/7 🚀\n\nScrivimi *qualsiasi cosa*: campagne, budget, creatività, Google Ads, ROAS, problemi account.",
    },
  ]);

  const boxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
    }, 30);
    return () => clearTimeout(t);
  }, [open, messages]);

  const ui = useMemo(() => {
    const bg = "rgba(10, 12, 18, 0.92)";
    const card = "rgba(255,255,255,0.06)";
    const border = "rgba(255,255,255,0.12)";
    const text = "rgba(255,255,255,0.92)";
    const sub = "rgba(255,255,255,0.70)";
    const blue = "#2D6CFF";
    const violet = "#7B61FF";
    const cyan = "#3EF3FF";
    const dark = "rgba(12,14,20,0.88)";
    return { bg, card, border, text, sub, blue, violet, cyan, dark };
  }, []);

  // Avatar "assistente neurale" (più professionale)
  const avatar = useMemo(() => {
    const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140">
  <defs>
    <radialGradient id="g" cx="30%" cy="25%" r="80%">
      <stop offset="0" stop-color="${ui.cyan}" stop-opacity="0.95"/>
      <stop offset="0.55" stop-color="${ui.violet}" stop-opacity="0.92"/>
      <stop offset="1" stop-color="${ui.blue}" stop-opacity="0.92"/>
    </radialGradient>
    <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="3" result="b"/>
      <feMerge>
        <feMergeNode in="b"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>

  <circle cx="70" cy="70" r="62" fill="url(#g)" opacity="0.26"/>
  <circle cx="70" cy="70" r="54" fill="rgba(0,0,0,0.30)" stroke="rgba(255,255,255,0.22)" stroke-width="2"/>
  <circle cx="70" cy="70" r="40" fill="rgba(255,255,255,0.96)"/>

  <!-- occhi "AI" -->
  <circle cx="56" cy="66" r="6" fill="#0B0F1A"/>
  <circle cx="84" cy="66" r="6" fill="#0B0F1A"/>
  <circle cx="56" cy="66" r="2.5" fill="${ui.cyan}" filter="url(#glow)"/>
  <circle cx="84" cy="66" r="2.5" fill="${ui.cyan}" filter="url(#glow)"/>

  <!-- sorriso -->
  <path d="M54 88c8 9 24 9 32 0" fill="none" stroke="#0B0F1A" stroke-width="5" stroke-linecap="round"/>

  <!-- micro "circuiti" -->
  <path d="M70 34v10M70 96v10M34 70h10M96 70h10" stroke="rgba(255,255,255,0.35)" stroke-width="2" stroke-linecap="round"/>
</svg>`;
    return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
  }, [ui.blue, ui.violet, ui.cyan]);

  // Risposta demo intelligente (se l'API locale risponde con echo/placeholder)
  function demoAnswer(userText: string) {
    const t = userText.toLowerCase();

    if (t.includes("ciao") || t.includes("hello")) {
      return "Ciao Roby 👋 dimmi cosa vuoi fare oggi: ottimizzare una campagna, controllare KPI o collegare Google Ads?";
    }
    if (t.includes("google") || t.includes("ads") || t.includes("oauth") || t.includes("refresh")) {
      return "✅ Google Ads: per andare LIVE servono Developer Token + OAuth + Refresh Token. Vuoi che partiamo dal refresh token e poi leggiamo KPI reali?";
    }
    if (t.includes("budget") || t.includes("spesa") || t.includes("cpa") || t.includes("roas")) {
      return "💰 Budget: dimmi obiettivo (lead/vendite), budget giornaliero e target (CPA o ROAS). Ti preparo regole di spostamento automatico e alert.";
    }
    if (t.includes("creativ") || t.includes("copy") || t.includes("annunci")) {
      return "🎨 Creatività: dimmi settore + offerta + target. Ti creo 5 varianti (titoli, descrizioni, CTA) pronte per test A/B.";
    }
    if (t.includes("kpi") || t.includes("ctr") || t.includes("cpc") || t.includes("conversion")) {
      return "📊 KPI: posso mostrarti CTR, CPC, ROAS e conversioni. Se mi dici quale campagna vuoi analizzare, ti dico dove sta perdendo performance e come sistemarla.";
    }
    return "Perfetto. Dimmi il tuo obiettivo (lead o vendite) e che budget vuoi usare: io ti guido step-by-step come un Ads Manager neurale.";
  }

  async function send() {
    const text = input.trim();
    if (!text || loading) return;

    setInput("");
    const next = [...messages, { role: "user", content: text } as Msg];
    setMessages(next);
    setLoading(true);

    try {
      // Usa endpoint esistente: /api/chat se c'è, altrimenti /api/chatbot
      let endpoint = "/api/chat";
      // fallback se /api/chat non esiste lato file: lo capiamo dal browser? qui no,
      // ma se fallisce la chiamata passiamo a /api/chatbot.
      let res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });

      if (!res.ok) {
        endpoint = "/api/chatbot";
        res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: next }),
        });
      }

      if (!res.ok) throw new Error("API non disponibile: " + res.status);

      const data = await res.json();

      // Prende vari formati possibili
      const raw =
        data?.message ??
        data?.reply ??
        data?.text ??
        data?.choices?.[0]?.message?.content ??
        "";

      const answer = String(raw || "").trim();

      // 🚫 BLOCCO: se l'API locale fa echo "Ricevuto ✅ / Messaggio: ..."
      const looksLikeEcho =
        answer.toLowerCase().includes("ricevuto") ||
        answer.toLowerCase().includes("messaggio:") ||
        answer.toLowerCase().includes("modalità demo");

      setMessages((m) => [
        ...m,
        { role: "assistant", content: looksLikeEcho ? demoAnswer(text) : answer || demoAnswer(text) },
      ]);
    } catch (e) {
      // fallback demo senza rompere l’esperienza
      setMessages((m) => [...m, { role: "assistant", content: demoAnswer(text) }]);
    } finally {
      setLoading(false);
    }
  }

  const ringAnim = `
    @keyframes aarRing { 0%{ transform: rotate(0deg)} 100%{ transform: rotate(360deg)} }
    @keyframes aarFloat { 0%,100%{ transform: translateY(0px)} 50%{ transform: translateY(-2px)} }
  `;

  return (
    <>
      <style>{ringAnim}</style>

      {/* BOTTONE (1 SOLO) */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Apri AI Ads Assistant"
          style={{
            position: "fixed",
            right: 22,
            bottom: 22,
            width: 74,
            height: 74,
            borderRadius: 999,
            border: `1px solid ${ui.border}`,
            background: "transparent",
            padding: 0,
            cursor: "pointer",
            zIndex: 99999,
            boxShadow: "0 18px 58px rgba(0,0,0,0.65)",
            animation: "aarFloat 2.8s ease-in-out infinite",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 999,
              background: `conic-gradient(from 220deg, ${ui.cyan}, ${ui.violet}, ${ui.blue}, ${ui.cyan})`,
              opacity: 0.95,
              animation: "aarRing 5.5s linear infinite",
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 8,
              borderRadius: 999,
              background: ui.dark,
              border: `1px solid ${ui.border}`,
              display: "grid",
              placeItems: "center",
              backdropFilter: "blur(12px)",
            }}
          >
            <img src={avatar} alt="AI Ads Assistant" style={{ width: 54, height: 54, borderRadius: 999 }} />
          </div>
        </button>
      )}

      {/* PANEL */}
      {open && (
        <div
          style={{
            position: "fixed",
            right: 18,
            bottom: 18,
            width: 460,
            maxWidth: "calc(100vw - 36px)",
            height: 640,
            maxHeight: "calc(100vh - 36px)",
            background: ui.bg,
            border: `1px solid ${ui.border}`,
            borderRadius: 18,
            zIndex: 99999,
            overflow: "hidden",
            boxShadow: "0 26px 100px rgba(0,0,0,0.72)",
            backdropFilter: "blur(16px)",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 14px",
              borderBottom: `1px solid ${ui.border}`,
              background: "rgba(255,255,255,0.03)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 999,
                  background: `conic-gradient(from 210deg, ${ui.cyan}, ${ui.violet}, ${ui.blue}, ${ui.cyan})`,
                  padding: 2,
                  display: "grid",
                  placeItems: "center",
                }}
              >
                <div
                  style={{
                    width: "100%",
                    height: "100%",
                    borderRadius: 999,
                    background: ui.dark,
                    border: `1px solid ${ui.border}`,
                    display: "grid",
                    placeItems: "center",
                  }}
                >
                  <img src={avatar} alt="assistant" style={{ width: 36, height: 36, borderRadius: 999 }} />
                </div>
              </div>

              <div>
                <div style={{ color: ui.text, fontWeight: 950, lineHeight: 1.1 }}>AI Ads Assistant</div>
                <div style={{ color: ui.sub, fontSize: 12 }}>Disponibile 24 ore su 24 🚀</div>
              </div>
            </div>

            <button
              onClick={() => setOpen(false)}
              aria-label="Chiudi"
              style={{
                width: 36,
                height: 36,
                borderRadius: 12,
                border: `1px solid ${ui.border}`,
                background: "rgba(255,255,255,0.03)",
                color: ui.text,
                cursor: "pointer",
                fontSize: 16,
              }}
            >
              ✕
            </button>
          </div>

          <div
            style={{
              padding: "10px 14px",
              borderBottom: `1px solid ${ui.border}`,
              color: ui.sub,
              fontSize: 12,
              background: "rgba(255,255,255,0.02)",
            }}
          >
            Ricorda che i tuoi dati saranno trattati secondo l’informativa privacy.
          </div>

          <div
            ref={boxRef}
            style={{
              padding: 14,
              height: 440,
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: 10,
            }}
          >
            {messages.map((m, i) => {
              const isUser = m.role === "user";
              return (
                <div
                  key={i}
                  style={{
                    alignSelf: isUser ? "flex-end" : "flex-start",
                    maxWidth: "86%",
                    padding: "10px 12px",
                    borderRadius: 14,
                    whiteSpace: "pre-wrap",
                    color: ui.text,
                    background: isUser ? `linear-gradient(135deg, ${ui.blue}, ${ui.violet})` : ui.card,
                    border: isUser ? "none" : `1px solid ${ui.border}`,
                  }}
                >
                  {m.content.replace(/\*\*(.*?)\*\*/g, "$1")}
                </div>
              );
            })}
          </div>

          <div style={{ padding: 14, borderTop: `1px solid ${ui.border}`, display: "flex", gap: 10 }}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder={loading ? "Sto scrivendo..." : "Scrivi qui il tuo messaggio…"}
              style={{
                flex: 1,
                padding: "12px 12px",
                borderRadius: 14,
                border: `1px solid ${ui.border}`,
                background: "rgba(0,0,0,0.25)",
                color: ui.text,
                outline: "none",
              }}
            />
            <button
              onClick={send}
              disabled={loading}
              style={{
                padding: "12px 16px",
                borderRadius: 14,
                border: `1px solid ${ui.border}`,
                background: `linear-gradient(135deg, ${ui.blue}, ${ui.violet})`,
                opacity: loading ? 0.7 : 1,
                color: "white",
                fontWeight: 950,
                cursor: "pointer",
              }}
            >
              Invia
            </button>
          </div>
        </div>
      )}
    </>
  );
}
