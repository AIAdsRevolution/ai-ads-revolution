"use client";
import React, { useEffect, useRef, useState } from "react";

type Msg = { role: "assistant" | "user"; text: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      text:
        "Ciao, sono l’assistente virtuale AI Ads Revolution, disponibile 24 ore su 24 🚀\n\nDimmi cosa vuoi fare:\n• Campagne\n• Budget\n• Creatività\n• Collegamento Google Ads",
    },
  ]);

  const boxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
    }, 50);
    return () => clearTimeout(t);
  }, [open, messages]);

  function demoReply(t: string) {
    const s = t.toLowerCase();
    if (s.includes("google") || s.includes("ads"))
      return "✅ Per collegare Google Ads: Developer Token + OAuth + Refresh Token. Quando vuoi lo rendiamo LIVE e leggiamo KPI reali.";
    if (s.includes("budget"))
      return "💰 Budget: dimmi obiettivo (lead/vendite) e budget giornaliero. Ti preparo regole (ROAS/CPA) per spostamento automatico.";
    if (s.includes("creativ"))
      return "🎨 Creatività: dimmi settore, offerta e target. Ti preparo 5 varianti pronte + idee A/B test.";
    if (s.includes("campagn"))
      return "📣 Campagne: dimmi obiettivo e paese. Ti suggerisco struttura (Search/PMAX/Display) e naming standard.";
    return "Ok ✅ Dimmi meglio cosa vuoi ottenere e ti guido step-by-step.";
  }

  async function send() {
    const t = input.trim();
    if (!t) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: t }]);
    const reply = demoReply(t);
    setTimeout(() => setMessages((m) => [...m, { role: "assistant", text: reply }]), 250);
  }

  const border = "rgba(255,255,255,.12)";
  const bg = "rgba(15, 20, 32, .92)";
  const soft = "rgba(255,255,255,.06)";
  const text = "rgba(255,255,255,.92)";
  const muted = "rgba(255,255,255,.70)";
  const accent = "#2563EB";
  const accent2 = "#7B61FF";

  return (
    <>
      {/* FLOAT BUTTON */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          style={{
            position: "fixed",
            right: 22,
            bottom: 22,
            width: 62,
            height: 62,
            borderRadius: 999,
            border: `1px solid ${border}`,
            background: `linear-gradient(135deg, ${accent}, ${accent2})`,
            boxShadow: "0 18px 50px rgba(0,0,0,.55)",
            zIndex: 99999,
            cursor: "pointer",
            display: "grid",
            placeItems: "center",
            color: "white",
            fontWeight: 900,
            letterSpacing: 0.5,
          }}
          aria-label="Apri assistente AI"
        >
          AI
        </button>
      )}

      {/* PANEL */}
      {open && (
        <div
          style={{
            position: "fixed",
            right: 18,
            bottom: 18,
            width: 390,
            maxWidth: "calc(100vw - 36px)",
            height: 540,
            maxHeight: "calc(100vh - 36px)",
            background: bg,
            border: `1px solid ${border}`,
            borderRadius: 16,
            zIndex: 99999,
            overflow: "hidden",
            boxShadow: "0 22px 70px rgba(0,0,0,.6)",
            backdropFilter: "blur(14px)",
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 10,
              padding: "12px 12px",
              borderBottom: `1px solid ${border}`,
              background: "rgba(255,255,255,.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 999,
                  background: `linear-gradient(135deg, ${accent}, ${accent2})`,
                  display: "grid",
                  placeItems: "center",
                  color: "white",
                  fontWeight: 900,
                }}
              >
                AI
              </div>
              <div style={{ lineHeight: 1.1 }}>
                <div style={{ color: text, fontWeight: 800 }}>AI Ads Assistant</div>
                <div style={{ color: muted, fontSize: 12 }}>Disponibile 24/7 🚀</div>
              </div>
            </div>

            <button
              onClick={() => setOpen(false)}
              style={{
                width: 34,
                height: 34,
                borderRadius: 10,
                border: `1px solid ${border}`,
                background: soft,
                color: text,
                cursor: "pointer",
              }}
              aria-label="Chiudi"
              title="Chiudi"
            >
              ✕
            </button>
          </div>

          {/* Messages */}
          <div
            ref={boxRef}
            style={{
              padding: 12,
              height: "calc(100% - 120px)",
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: 10,
            }}
          >
            {messages.map((m, idx) => {
              const isUser = m.role === "user";
              return (
                <div
                  key={idx}
                  style={{
                    alignSelf: isUser ? "flex-end" : "flex-start",
                    maxWidth: "88%",
                    padding: "10px 12px",
                    borderRadius: 14,
                    border: `1px solid ${border}`,
                    background: isUser ? "rgba(37,99,235,.18)" : "rgba(255,255,255,.04)",
                    color: text,
                    whiteSpace: "pre-wrap",
                    boxShadow: "0 10px 30px rgba(0,0,0,.25)",
                  }}
                >
                  {m.text}
                </div>
              );
            })}
          </div>

          {/* Input */}
          <div
            style={{
              padding: 12,
              borderTop: `1px solid ${border}`,
              display: "flex",
              gap: 10,
              background: "rgba(255,255,255,.02)",
            }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
              }}
              placeholder="Scrivi qui la tua richiesta…"
              style={{
                flex: 1,
                height: 42,
                borderRadius: 12,
                border: `1px solid ${border}`,
                background: "rgba(0,0,0,.25)",
                color: text,
                padding: "0 12px",
                outline: "none",
              }}
            />
            <button
              onClick={send}
              style={{
                height: 42,
                padding: "0 14px",
                borderRadius: 12,
                border: `1px solid ${border}`,
                background: `linear-gradient(135deg, ${accent}, ${accent2})`,
                color: "white",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              Invia
            </button>
          </div>
        </div>
      )}
    </>
  );
}
