import { NextResponse } from 'next/server'
import { supabase } from '@/supabase/client'

function randomBetween(min: number, max: number) {
  return Math.random() * (max - min) + min
}

export async function POST() {

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !anon) {
    return NextResponse.json(
      { ok:false, error:"Missing Supabase env vars", missing: {
        NEXT_PUBLIC_SUPABASE_URL: !supabaseUrl,
        NEXT_PUBLIC_SUPABASE_ANON_KEY: !anon
      }},
      { status: 500 }
    );
  }
  // Simula update di una campagna AI
  const campaigns = ['CAMP-preview-1', 'CAMP-preview-2', 'CAMP-preview-3']

  const campaign_id =
    campaigns[Math.floor(Math.random() * campaigns.length)]

  const impressions = Math.floor(randomBetween(100, 800))
  const clicks = Math.floor(impressions * randomBetween(0.03, 0.15))
  const cost_eur = Number(randomBetween(5, 25).toFixed(2))
  const revenue_eur = Number(
    (cost_eur * randomBetween(1.5, 6)).toFixed(2)
  )

  const { error } = await supabase.from('campaign_metrics').insert({
    campaign_id,
    impressions,
    clicks,
    cost_eur,
    revenue_eur,
  })

  if (error) {
    console.error('Errore insert simulatore metrics:', error)
    return NextResponse.json(
      {
        ok: false,
        error: String(error),
      },
      { status: 500 }
    )
  }

  return NextResponse.json({
    ok: true,
    campaign_id,
    impressions,
    clicks,
    cost_eur,
    revenue_eur,
  })
}
