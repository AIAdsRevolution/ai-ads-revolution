import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseClient";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { campaign, metrics } = body;

    const impressions = Number(metrics.impressions || 0);
    const clicks = Number(metrics.clicks || 0);
    const conversions = Number(metrics.conversions || 0);

    const costEUR = metrics.cost_micros
      ? Number(metrics.cost_micros) / 1_000_000
      : 0;

    const revenueEUR = metrics.conversions_value
      ? Number(metrics.conversions_value)
      : 0;

    const roas = costEUR > 0 ? revenueEUR / costEUR : 0;

    const { error } = await supabase.from("campaign_metrics").insert({
      campaign_id: campaign.id,
      campaign_name: campaign.name,
      impressions,
      clicks,
      conversions,
      cost: costEUR,
      cost_eur: costEUR,
      revenue: revenueEUR,
      revenue_eur: revenueEUR,
      roas,
      date: new Date().toISOString().slice(0, 10),
      ts: new Date().toISOString()
    });

    if (error) {
      console.error("❌ Supabase insert error:", error);
      return NextResponse.json({ ok: false, error }, { status: 500 });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("❌ API error:", e);
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function GET() {
  try {
    // Ultimi 28 giorni (default)
    const from = new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString().slice(0,10);

    const { data, error } = await supabase
      .from("campaign_metrics")
      .select("date,campaign_id,campaign_name,impressions,clicks,conversions,cost_eur,revenue_eur,roas,ts")
      .gte("date", from)
      .order("ts", { ascending: false })
      .limit(300);

    if (error) {
      console.error("❌ Supabase read error:", error);
      return NextResponse.json({ ok: false, error }, { status: 500 });
    }

    return NextResponse.json({ ok: true, data });
  } catch (e) {
    console.error("❌ GET API error:", e);
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
