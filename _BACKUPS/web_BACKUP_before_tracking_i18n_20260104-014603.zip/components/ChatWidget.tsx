"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";

type Msg = { role: "assistant" | "user"; text: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      text:
        "Ciao 👋 sono l’assistente AI Ads Revolution, disponibile 24/7 🚀\n\nDimmi cosa vuoi fare:\n• Campagne\n• Budget\n• Creatività\n• Collegamento Google Ads",
    },
  ]);

  const boxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
    }, 50);
    return () => clearTimeout(t);
  }, [open, messages]);

  const ui = useMemo(() => {
    const panelBg = "rgba(12, 14, 20, 0.92)";
    const border = "rgba(255,255,255,0.12)";
    const soft = "rgba(255,255,255,0.06)";
    const text = "rgba(255,255,255,0.92)";
    const sub = "rgba(255,255,255,0.65)";
    const blue = "#2D6CFF";
    const violet = "#7B61FF";
    const cyan = "#3EF3FF";
    return { panelBg, border, soft, text, sub, blue, violet, cyan };
  }, []);

  const faceSvg = useMemo(() => {
    // Icona faccina embedded (zero 404)
    const svg =
      `<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' viewBox='0 0 64 64'>
        <defs>
          <linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>
            <stop offset='0' stop-color='${ui.cyan}'/>
            <stop offset='0.55' stop-color='${ui.violet}'/>
            <stop offset='1' stop-color='${ui.blue}'/>
          </linearGradient>
        </defs>
        <circle cx='32' cy='32' r='30' fill='url(#g)' opacity='0.18'/>
        <circle cx='32' cy='32' r='22' fill='white' opacity='0.92'/>
        <circle cx='24' cy='30' r='3.2' fill='#1b2230'/>
        <circle cx='40' cy='30' r='3.2' fill='#1b2230'/>
        <path d='M23 40c3.5 4 14.5 4 18 0' fill='none' stroke='#1b2230' stroke-width='3' stroke-linecap='round'/>
      </svg>`;
    return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
  }, [ui.blue, ui.violet, ui.cyan]);

  async function send() {
    const t = input.trim();
    if (!t) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: t }]);

    const low = t.toLowerCase();
    let reply =
      low.includes("google") || low.includes("ads")
        ? "✅ Collegamento Google Ads: Developer Token + OAuth + Refresh Token. Quando vuoi lo rendiamo LIVE e leggiamo KPI reali."
        : low.includes("budget")
        ? "💰 Budget: dimmi obiettivo (lead/vendite) e budget giornaliero. Ti preparo regole (ROAS/CPA) per spostamento automatico."
        : low.includes("creativ")
        ? "🎨 Creatività: dimmi settore + offerta + target. Ti preparo 5 varianti annuncio + 5 hook pronti."
        : low.includes("campagn")
        ? "📣 Campagne: vuoi Search, Performance Max o Meta? Dimmi obiettivo e paese e ti creo la struttura consigliata."
        : "Ok ✅ Dimmi obiettivo e cosa vuoi ottimizzare (CPC, CPA, ROAS).";

    setTimeout(() => {
      setMessages((m) => [...m, { role: "assistant", text: reply }]);
    }, 280);
  }

  return (
    <>
      {/* LAUNCHER (SKY-LIKE) */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Apri assistente"
          style={{
            position: "fixed",
            right: 22,
            bottom: 22,
            width: 66,
            height: 66,
            borderRadius: 999,
            border: `1px solid ${ui.border}`,
            background: "rgba(0,0,0,0.15)",
            boxShadow: "0 18px 55px rgba(0,0,0,0.60)",
            zIndex: 99999,
            cursor: "pointer",
            padding: 0,
          }}
        >
          {/* ring */}
          <div
            style={{
              position: "absolute",
              inset: 2,
              borderRadius: 999,
              background: `conic-gradient(from 200deg, ${ui.cyan}, ${ui.violet}, ${ui.blue}, ${ui.cyan})`,
              filter: "saturate(1.2)",
              opacity: 0.95,
            }}
          />
          {/* inner */}
          <div
            style={{
              position: "absolute",
              inset: 6,
              borderRadius: 999,
              background: "rgba(12,14,20,0.88)",
              border: `1px solid ${ui.border}`,
              display: "grid",
              placeItems: "center",
              backdropFilter: "blur(10px)",
            }}
          >
            <img
              src={faceSvg}
              alt="assistant"
              style={{
                width: 52,
                height: 52,
                borderRadius: 999,
                display: "block",
              }}
            />
          </div>
        </button>
      )}

      {/* PANEL (SKY-LIKE) */}
      {open && (
        <div
          style={{
            position: "fixed",
            right: 18,
            bottom: 18,
            width: 420,
            maxWidth: "calc(100vw - 36px)",
            height: 560,
            maxHeight: "calc(100vh - 36px)",
            background: ui.panelBg,
            border: `1px solid ${ui.border}`,
            borderRadius: 18,
            zIndex: 99999,
            overflow: "hidden",
            boxShadow: "0 26px 85px rgba(0,0,0,0.65)",
            backdropFilter: "blur(16px)",
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 12px",
              borderBottom: `1px solid ${ui.border}`,
              background: "rgba(255,255,255,0.03)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 999,
                  background: `conic-gradient(from 210deg, ${ui.cyan}, ${ui.violet}, ${ui.blue}, ${ui.cyan})`,
                  display: "grid",
                  placeItems: "center",
                  padding: 2,
                }}
              >
                <div
                  style={{
                    width: "100%",
                    height: "100%",
                    borderRadius: 999,
                    background: "rgba(12,14,20,0.85)",
                    border: `1px solid ${ui.border}`,
                    display: "grid",
                    placeItems: "center",
                  }}
                >
                  <img src={faceSvg} alt="assistant" style={{ width: 30, height: 30, borderRadius: 999 }} />
                </div>
              </div>

              <div>
                <div style={{ color: ui.text, fontWeight: 850, lineHeight: 1.1 }}>
                  AI Ads Assistant
                </div>
                <div style={{ color: ui.sub, fontSize: 12 }}>
                  Disponibile 24/7 🚀
                </div>
              </div>
            </div>

            <button
              onClick={() => setOpen(false)}
              aria-label="Chiudi"
              style={{
                width: 36,
                height: 36,
                borderRadius: 12,
                border: `1px solid ${ui.border}`,
                background: "transparent",
                color: ui.text,
                cursor: "pointer",
                fontSize: 16,
              }}
            >
              ✕
            </button>
          </div>

          {/* Privacy note */}
          <div
            style={{
              padding: "10px 12px",
              borderBottom: `1px solid ${ui.border}`,
              color: ui.sub,
              fontSize: 12,
              lineHeight: 1.35,
            }}
          >
            Ricorda che i tuoi dati saranno trattati secondo l’informativa privacy.
          </div>

          {/* Messages */}
          <div
            ref={boxRef}
            style={{
              padding: 12,
              height: 390,
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: 10,
            }}
          >
            {messages.map((m, i) => {
              const isUser = m.role === "user";
              return (
                <div
                  key={i}
                  style={{
                    alignSelf: isUser ? "flex-end" : "flex-start",
                    maxWidth: "86%",
                    padding: "10px 12px",
                    borderRadius: 14,
                    whiteSpace: "pre-wrap",
                    color: ui.text,
                    background: isUser
                      ? `linear-gradient(135deg, ${ui.blue}, ${ui.violet})`
                      : ui.soft,
                    border: isUser ? "none" : `1px solid ${ui.border}`,
                  }}
                >
                  {m.text}
                </div>
              );
            })}
          </div>

          {/* Input */}
          <div
            style={{
              padding: 12,
              borderTop: `1px solid ${ui.border}`,
              display: "flex",
              gap: 10,
              background: "rgba(255,255,255,0.02)",
            }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") send(); }}
              placeholder="Scrivi qui la tua richiesta…"
              style={{
                flex: 1,
                padding: "10px 12px",
                borderRadius: 12,
                border: `1px solid ${ui.border}`,
                background: "rgba(0,0,0,0.25)",
                color: ui.text,
                outline: "none",
              }}
            />
            <button
              onClick={send}
              style={{
                padding: "10px 14px",
                borderRadius: 12,
                border: `1px solid ${ui.border}`,
                background: `linear-gradient(135deg, ${ui.blue}, ${ui.violet})`,
                color: "white",
                fontWeight: 850,
                cursor: "pointer",
              }}
            >
              Invia
            </button>
          </div>
        </div>
      )}
    </>
  );
}
